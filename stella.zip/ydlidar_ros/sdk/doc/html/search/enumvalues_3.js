var searchData=
[
  ['receives',['Receives',['../classydlidar_1_1_c_simple_socket.html#a7eae391e0dcbafd740488b9a269c8eeeaeb0f1c6410f5b9f5b03274e9d90592fd',1,'ydlidar::CSimpleSocket']]]
];
