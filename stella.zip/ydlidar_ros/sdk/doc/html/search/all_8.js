var searchData=
[
  ['handledeviceinfopackage',['handleDeviceInfoPackage',['../class_c_yd_lidar.html#a402f601e56a3bdb6b87bc1e4c2d35539',1,'CYdLidar']]],
  ['handlesinglechanneldevice',['handleSingleChannelDevice',['../class_c_yd_lidar.html#a3f6a6ba2b6db3cf3f57d7feb5b25d527',1,'CYdLidar']]],
  ['hardware_5fid',['hardware_id',['../structserial_1_1_port_info.html#a7d55368e1a4e6ccc9da6f4d339524837',1,'serial::PortInfo']]],
  ['hardware_5fversion',['hardware_version',['../structdevice__info.html#add77e9b0edbc4a0dbd8f91b0cac9ea13',1,'device_info']]]
];
