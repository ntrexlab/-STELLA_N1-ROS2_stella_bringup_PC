var searchData=
[
  ['offset_5fangle',['offset_angle',['../structoffset__angle.html',1,'']]]
];
