var searchData=
[
  ['write_5ftimeout_5fconstant',['write_timeout_constant',['../structserial_1_1_timeout.html#accf01b97f83564f4ce3d6e5f63e21006',1,'serial::Timeout']]],
  ['write_5ftimeout_5fmultiplier',['write_timeout_multiplier',['../structserial_1_1_timeout.html#a31ddae32907cff9c3d27fa763981317d',1,'serial::Timeout']]]
];
