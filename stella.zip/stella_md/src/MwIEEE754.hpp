#include <limits.h>
#include <iostream>
#include <math.h>
#include <bitset>

void Binary2Hex( std::string Binary, int8_t hex[4]);
std::string GetBinary32( float value );